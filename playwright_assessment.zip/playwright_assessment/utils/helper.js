export function generateUniqueUsername() {
    return `user_${Date.now()}`;
}